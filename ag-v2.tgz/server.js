// server.js — REST API + realtime broadcast for the AG voting tool.
//
// Design: plain REST endpoints do the actual state changes (create/open/close
// a question, cast a vote); each handler then emits a Socket.IO event so
// every connected browser (admin dashboard, every voter's phone) updates
// live without polling. Sockets are push-only here — no vote is ever cast
// over a socket, only broadcast through one, which keeps the "what changed
// the database" logic in one place (the REST handlers).
//
// Proxy ("procuration") voting: a normal voter is anonymous (random id
// generated client-side, always worth 1 vote). A proxy holder instead uses a
// personal link containing a token the admin generated for them from the
// President's private list. Since v2 a proxy holder gets one separate
// ballot per person they represent (ballot 0 = their own vote, ballots
// 1..n = each proxy, named), so they can vote differently for each one.
// How many ballots a token has lives only in the `voters` table and is
// looked up server-side — a client can never claim extra ballots.

require('dotenv').config();
const path = require('path');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { v4: uuidv4 } = require('uuid');
const { pool, init } = require('./db');
const webpush = require('web-push');

const PORT = process.env.PORT || 3000;
const ADMIN_PIN = process.env.ADMIN_PIN || 'changeme'; // set a real one in .env before deploying

// Web Push: silently disabled (rather than crashing) if the keys aren't in
// .env yet -- lets an existing deployment keep running after this update
// until someone generates and sets a VAPID key pair.
const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY;
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY;
const VAPID_CONTACT_EMAIL = process.env.VAPID_CONTACT_EMAIL || 'mailto:admin@example.com';
const pushEnabled = Boolean(VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY);
if (pushEnabled) {
  webpush.setVapidDetails(VAPID_CONTACT_EMAIL, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
} else {
  console.warn('VAPID_PUBLIC_KEY/VAPID_PRIVATE_KEY not set in .env — push notifications are disabled.');
}

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// The bare root URL (what people actually get sent — "vote.epfl-rocket-team.ch",
// not "…/voter.html") has no matching static file (no public/index.html), so
// without this it 404s. Voters are the intended audience at "/"; the admin
// panel stays reachable only at its own explicit /admin.html.
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'voter.html'));
});

// Projector view for the room (big question, live count, timer, results).
app.get('/ecran', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'screen.html'));
});

// Wrap async route handlers so a thrown/rejected error reaches Express's
// error middleware instead of crashing the process or hanging the request.
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);

// ---------- helpers ----------

const STANDARD_CHOICES = ['Oui', 'Non', 'Blanc'];

function questionRow(q) {
  return {
    id: q.id,
    text: q.text,
    type: q.type, // 'standard' (fixed Oui/Non/Blanc) or 'custom' (own options)
    options: q.options ?? null, // JSONB comes back already parsed; only set for 'custom'
    status: q.status,
    orderIndex: q.order_index,
    // Countdown (optional): sent as "milliseconds left" rather than an
    // absolute time, so a phone with a wrong clock still shows it right.
    timerRemainingMs: q.timer_ends_at ? Math.max(0, new Date(q.timer_ends_at).getTime() - Date.now()) : null,
    timerAutoClose: Boolean(q.timer_auto_close),
  };
}

// The ballots a proxy link can cast: 0 = the holder's own vote, then one per
// represented person. Older links (created before v2, weight only, no names)
// get generic labels for their extra ballots.
function ballotsFor(voterRow) {
  const names = Array.isArray(voterRow.proxy_names) ? voterRow.proxy_names : [];
  const count = Math.max(voterRow.weight, 1 + names.length);
  const ballots = [{ index: 0, label: voterRow.display_name, own: true }];
  for (let i = 1; i < count; i++) {
    ballots.push({ index: i, label: names[i - 1] || `Procuration ${i}`, own: false });
  }
  return ballots;
}

function choicesFor(q) {
  return q.type === 'standard' ? STANDARD_CHOICES : q.options || [];
}

async function getQuestion(id) {
  const { rows } = await pool.query('SELECT * FROM questions WHERE id = $1', [id]);
  return rows[0] || null;
}

async function tallyFor(questionId) {
  const { rows } = await pool.query(
    'SELECT choice, SUM(weight) as weighted_count FROM votes WHERE question_id = $1 GROUP BY choice',
    [questionId]
  );
  const tally = {};
  let total = 0;
  for (const row of rows) {
    const count = parseInt(row.weighted_count, 10); // pg returns SUM() as a string
    tally[row.choice] = count;
    total += count;
  }
  return { tally, total };
}

// How many individual vote rows (not weighted) are recorded for a question —
// used for the "N votes reçus" counter shown while a question is still open,
// deliberately without revealing the breakdown by choice.
async function voteRowCountFor(questionId) {
  const { rows } = await pool.query('SELECT COUNT(*) as c FROM votes WHERE question_id = $1', [questionId]);
  return parseInt(rows[0].c, 10);
}

// Sends a small "a question just opened" nudge to every browser that opted
// in -- never any vote content, just enough to make someone look at their
// phone. Dead subscriptions (permission revoked, browser data cleared) are
// cleaned up here rather than retried forever.
async function notifyAllSubscribers(payload) {
  if (!pushEnabled) return;
  const { rows } = await pool.query('SELECT endpoint, subscription FROM push_subscriptions');
  const body = JSON.stringify(payload);
  await Promise.all(
    rows.map(async (row) => {
      try {
        await webpush.sendNotification(row.subscription, body);
      } catch (err) {
        if (err.statusCode === 404 || err.statusCode === 410) {
          await pool.query('DELETE FROM push_subscriptions WHERE endpoint = $1', [row.endpoint]);
        } else {
          console.error('Push notification failed for a subscriber:', err.message);
        }
      }
    })
  );
}

// ---------- closing + countdown timers ----------

const timers = new Map(); // questionId -> setTimeout handle (auto-close only)

function clearTimer(questionId) {
  const t = timers.get(questionId);
  if (t) clearTimeout(t);
  timers.delete(questionId);
}

// Single place a question gets closed (admin button, opening another
// question, or a countdown running out): status + timer reset in the DB,
// then the final tally is broadcast — that's the moment results go public.
async function closeQuestionById(questionId) {
  clearTimer(questionId);
  const { rowCount } = await pool.query(
    "UPDATE questions SET status = 'closed', closed_at = now(), timer_ends_at = NULL WHERE id = $1 AND status = 'open'",
    [questionId]
  );
  const { tally, total } = await tallyFor(questionId);
  if (rowCount > 0) io.emit('question:closed', { questionId, tally, total });
  return { tally, total };
}

function scheduleAutoClose(questionId, remainingMs) {
  clearTimer(questionId);
  timers.set(
    questionId,
    setTimeout(() => {
      timers.delete(questionId);
      closeQuestionById(questionId).catch((err) => console.error('Auto-close failed:', err.message));
    }, Math.max(0, remainingMs))
  );
}

function emitTimer(q) {
  const row = questionRow(q);
  io.emit('timer:update', {
    questionId: row.id,
    remainingMs: row.timerRemainingMs,
    autoClose: row.timerAutoClose,
  });
}

// simple shared-PIN auth for the admin/presenter endpoints — this isn't
// trying to be a real user auth system, just enough to stop a random voter
// from opening/closing questions from their phone.
function requireAdmin(req, res, next) {
  const token = req.get('x-admin-token');
  if (token !== ADMIN_PIN) {
    return res.status(401).json({ error: 'PIN administrateur invalide ou manquant.' });
  }
  next();
}

// ---------- admin auth ----------

app.post('/api/admin/verify', (req, res) => {
  const { pin } = req.body || {};
  if (pin === ADMIN_PIN) return res.json({ ok: true });
  return res.status(401).json({ ok: false, error: 'PIN incorrect.' });
});

// ---------- questions ----------

app.get(
  '/api/questions',
  wrap(async (req, res) => {
    const { rows } = await pool.query('SELECT * FROM questions ORDER BY order_index ASC');
    res.json(rows.map(questionRow));
  })
);

app.get(
  '/api/questions/:id',
  wrap(async (req, res) => {
    const q = await getQuestion(req.params.id);
    if (!q) return res.status(404).json({ error: 'Question introuvable.' });
    res.json(questionRow(q));
  })
);

// Live vote count only (no breakdown) — safe to show while a question is
// still open, since it doesn't reveal which way the room is leaning.
app.get(
  '/api/questions/:id/vote-count',
  wrap(async (req, res) => {
    const q = await getQuestion(req.params.id);
    if (!q) return res.status(404).json({ error: 'Question introuvable.' });
    const count = await voteRowCountFor(q.id);
    res.json({ questionId: q.id, voteCount: count });
  })
);

// Full breakdown with percentages — only once a question is closed. Refused
// while it's open: question ids are visible to every voter, so leaving this
// open would let anyone read the live breakdown with a single request.
app.get(
  '/api/questions/:id/results',
  wrap(async (req, res) => {
    const q = await getQuestion(req.params.id);
    if (!q) return res.status(404).json({ error: 'Question introuvable.' });
    if (q.status !== 'closed') {
      return res.status(403).json({ error: 'Les résultats sont disponibles après la fermeture du vote.' });
    }
    const { tally, total } = await tallyFor(q.id);
    res.json({ question: questionRow(q), tally, total });
  })
);

app.post(
  '/api/questions',
  requireAdmin,
  wrap(async (req, res) => {
    const { text, type, options } = req.body || {};
    if (!text || typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({ error: 'Le texte de la question est requis.' });
    }
    if (!['standard', 'custom'].includes(type)) {
      return res.status(400).json({ error: "type doit être 'standard' ou 'custom'." });
    }
    if (type === 'custom' && (!Array.isArray(options) || options.length < 2)) {
      return res.status(400).json({ error: 'Un choix personnalisé nécessite au moins 2 options.' });
    }

    const id = uuidv4();
    const { rows: orderRows } = await pool.query('SELECT COALESCE(MAX(order_index), -1) + 1 as next FROM questions');
    const orderIndex = orderRows[0].next;

    const { rows } = await pool.query(
      `INSERT INTO questions (id, text, type, options, status, order_index)
       VALUES ($1, $2, $3, $4, 'draft', $5)
       RETURNING *`,
      [id, text.trim(), type, type === 'custom' ? JSON.stringify(options) : null, orderIndex]
    );

    io.emit('questions:changed');
    res.status(201).json(questionRow(rows[0]));
  })
);

app.patch(
  '/api/questions/:id',
  requireAdmin,
  wrap(async (req, res) => {
    const q = await getQuestion(req.params.id);
    if (!q) return res.status(404).json({ error: 'Question introuvable.' });
    if (q.status !== 'draft') {
      return res.status(400).json({ error: 'Seules les questions en brouillon peuvent être modifiées.' });
    }
    const { text, type, options } = req.body || {};
    const newText = text !== undefined ? text.trim() : q.text;
    const newType = type !== undefined ? type : q.type;
    const newOptions = newType === 'custom' ? JSON.stringify(options ?? []) : null;

    const { rows } = await pool.query(
      'UPDATE questions SET text = $1, type = $2, options = $3 WHERE id = $4 RETURNING *',
      [newText, newType, newOptions, q.id]
    );
    io.emit('questions:changed');
    res.json(questionRow(rows[0]));
  })
);

app.delete(
  '/api/questions/:id',
  requireAdmin,
  wrap(async (req, res) => {
    const q = await getQuestion(req.params.id);
    if (!q) return res.status(404).json({ error: 'Question introuvable.' });
    // Draft or closed can be deleted (e.g. to clear out test questions after
    // a dry run) — only an OPEN question is blocked, since deleting one
    // mid-vote out from under connected voters would be genuinely confusing.
    if (q.status === 'open') {
      return res.status(400).json({ error: 'Ferme la question avant de la supprimer.' });
    }
    // votes.question_id references questions(id) without ON DELETE CASCADE,
    // so a closed question with votes attached must have them removed first
    // — otherwise Postgres rejects the delete with a foreign key violation.
    // Both deletes run in one transaction so we never end up with votes
    // orphaned by a question that got deleted (or vice versa) if something
    // fails halfway through.
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query('DELETE FROM votes WHERE question_id = $1', [q.id]);
      await client.query('DELETE FROM questions WHERE id = $1', [q.id]);
      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
    io.emit('questions:changed');
    res.status(204).end();
  })
);

app.post(
  '/api/questions/:id/open',
  requireAdmin,
  wrap(async (req, res) => {
    const q = await getQuestion(req.params.id);
    if (!q) return res.status(404).json({ error: 'Question introuvable.' });
    if (q.status === 'closed') {
      return res.status(400).json({ error: 'Cette question est déjà fermée.' });
    }

    // Only one question live at a time — close any other open one first.
    const { rows: openOthers } = await pool.query(
      "SELECT id FROM questions WHERE status = 'open' AND id != $1",
      [q.id]
    );
    for (const other of openOthers) {
      await closeQuestionById(other.id);
    }

    const { rows } = await pool.query(
      "UPDATE questions SET status = 'open', opened_at = now(), timer_ends_at = NULL, timer_auto_close = false WHERE id = $1 RETURNING *",
      [q.id]
    );
    io.emit('question:open', questionRow(rows[0]));
    // Fire-and-forget: a slow/failed push should never delay or fail the
    // admin's "open" action itself.
    notifyAllSubscribers({ title: 'Nouvelle question ouverte', body: rows[0].text }).catch((err) =>
      console.error('notifyAllSubscribers failed:', err.message)
    );
    res.json(questionRow(rows[0]));
  })
);

app.post(
  '/api/questions/:id/close',
  requireAdmin,
  wrap(async (req, res) => {
    const q = await getQuestion(req.params.id);
    if (!q) return res.status(404).json({ error: 'Question introuvable.' });
    if (q.status !== 'open') {
      return res.status(400).json({ error: 'Seule une question ouverte peut être fermée.' });
    }
    const { tally, total } = await closeQuestionById(q.id);
    res.json({ questionId: q.id, tally, total });
  })
);

// Countdown for the open question: shown on the projector and on phones.
// With autoClose the server closes the question itself when it runs out;
// without it, it's only a visual cue and the presenter closes by hand.
app.post(
  '/api/questions/:id/timer',
  requireAdmin,
  wrap(async (req, res) => {
    const q = await getQuestion(req.params.id);
    if (!q) return res.status(404).json({ error: 'Question introuvable.' });
    if (q.status !== 'open') {
      return res.status(400).json({ error: 'Le minuteur ne peut être lancé que sur la question ouverte.' });
    }
    const seconds = parseInt((req.body || {}).seconds, 10);
    if (!Number.isInteger(seconds) || seconds < 5 || seconds > 3600) {
      return res.status(400).json({ error: 'Durée invalide (entre 5 secondes et 60 minutes).' });
    }
    const autoClose = Boolean((req.body || {}).autoClose);
    const { rows } = await pool.query(
      "UPDATE questions SET timer_ends_at = now() + ($1 || ' seconds')::interval, timer_auto_close = $2 WHERE id = $3 RETURNING *",
      [String(seconds), autoClose, q.id]
    );
    if (autoClose) scheduleAutoClose(q.id, seconds * 1000);
    else clearTimer(q.id);
    emitTimer(rows[0]);
    res.json(questionRow(rows[0]));
  })
);

app.delete(
  '/api/questions/:id/timer',
  requireAdmin,
  wrap(async (req, res) => {
    clearTimer(req.params.id);
    const { rows } = await pool.query(
      'UPDATE questions SET timer_ends_at = NULL, timer_auto_close = false WHERE id = $1 RETURNING *',
      [req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Question introuvable.' });
    emitTimer(rows[0]);
    res.json(questionRow(rows[0]));
  })
);

// ---------- voting ----------

// Resolves who is voting: a proxy link (token) -> its ballots, or an
// anonymous phone (voterId) -> a single ballot. Returns null + sends the
// error response if the identity is invalid.
async function resolveVoter(body, res) {
  const { token, voterId } = body;
  if (token) {
    const { rows } = await pool.query('SELECT * FROM voters WHERE token = $1', [token]);
    if (!rows[0]) {
      res.status(403).json({ error: 'Lien de vote invalide ou expiré.' });
      return null;
    }
    return { rowId: token, ballots: ballotsFor(rows[0]) };
  }
  if (!voterId || typeof voterId !== 'string') {
    res.status(400).json({ error: 'voterId est requis pour un vote anonyme.' });
    return null;
  }
  return { rowId: voterId, ballots: [{ index: 0, label: null, own: true }] };
}

// Cast or change votes. Body: { questionId, token | voterId, and either
//   choice (+ optional ballot, default 0)  -- one ballot, or
//   votes: [{ ballot, choice }, ...]       -- several at once ("même choix
//                                             pour toutes mes voix") }.
// Every ballot is worth exactly 1 vote; which ballots a voter may use is
// decided only by the server (resolveVoter), never by the request.
app.post(
  '/api/vote',
  wrap(async (req, res) => {
    const body = req.body || {};
    const { questionId } = body;
    if (!questionId) return res.status(400).json({ error: 'questionId est requis.' });

    let votes = Array.isArray(body.votes)
      ? body.votes
      : [{ ballot: body.ballot === undefined ? 0 : body.ballot, choice: body.choice }];
    if (votes.length === 0 || votes.some((v) => !v || !v.choice)) {
      return res.status(400).json({ error: 'Choix manquant.' });
    }

    const q = await getQuestion(questionId);
    if (!q) return res.status(404).json({ error: 'Question introuvable.' });
    if (q.status !== 'open') {
      return res.status(400).json({ error: "Cette question n'est pas actuellement ouverte au vote." });
    }
    const allowedChoices = choicesFor(q);
    if (votes.some((v) => !allowedChoices.includes(v.choice))) {
      return res.status(400).json({ error: 'Choix invalide pour cette question.' });
    }

    const voter = await resolveVoter(body, res);
    if (!voter) return;
    const validBallots = new Set(voter.ballots.map((b) => b.index));
    votes = votes.map((v) => ({ ballot: parseInt(v.ballot, 10), choice: v.choice }));
    if (votes.some((v) => !validBallots.has(v.ballot))) {
      return res.status(403).json({ error: 'Bulletin invalide pour ce lien.' });
    }

    // One row per (question, voter, ballot) — voting again overwrites, so a
    // choice can be changed while the question is still open.
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      for (const v of votes) {
        await client.query(
          `INSERT INTO votes (question_id, voter_id, ballot, choice, weight) VALUES ($1, $2, $3, $4, 1)
           ON CONFLICT (question_id, voter_id, ballot)
           DO UPDATE SET choice = EXCLUDED.choice, weight = 1, created_at = now()`,
          [questionId, voter.rowId, v.ballot, v.choice]
        );
      }
      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }

    // Only this one safe aggregate number is broadcast while voting is open —
    // never the breakdown by choice. Results stay hidden until a question
    // closes; this is a deliberate requirement, not just a UI choice.
    const voteCount = await voteRowCountFor(questionId);
    io.emit('vote-count:update', { questionId, voteCount });
    res.json({ ok: true, saved: votes.length });
  })
);

// A voter's own current choices for a question (so a reloaded phone shows
// what it already voted). Only reachable with the voter's own secret id or
// proxy token — never anyone else's.
app.get(
  '/api/my-votes',
  wrap(async (req, res) => {
    const { questionId } = req.query;
    if (!questionId) return res.status(400).json({ error: 'questionId est requis.' });
    const voter = await resolveVoter(req.query, res);
    if (!voter) return;
    const { rows } = await pool.query(
      'SELECT ballot, choice FROM votes WHERE question_id = $1 AND voter_id = $2',
      [questionId, voter.rowId]
    );
    const choices = {};
    for (const r of rows) choices[r.ballot] = r.choice;
    res.json({ choices });
  })
);

// ---------- push notifications (opt-in, discreet nudge on open) ----------

app.get('/api/push/public-key', (req, res) => {
  res.json({ publicKey: pushEnabled ? VAPID_PUBLIC_KEY : null });
});

app.post(
  '/api/push/subscribe',
  wrap(async (req, res) => {
    const subscription = req.body;
    if (!subscription || !subscription.endpoint || !subscription.keys) {
      return res.status(400).json({ error: 'Abonnement push invalide.' });
    }
    await pool.query(
      `INSERT INTO push_subscriptions (endpoint, subscription) VALUES ($1, $2)
       ON CONFLICT (endpoint) DO UPDATE SET subscription = EXCLUDED.subscription`,
      [subscription.endpoint, JSON.stringify(subscription)]
    );
    res.status(201).json({ ok: true });
  })
);

app.delete(
  '/api/push/subscribe',
  wrap(async (req, res) => {
    const { endpoint } = req.body || {};
    if (!endpoint) return res.status(400).json({ error: 'endpoint est requis.' });
    await pool.query('DELETE FROM push_subscriptions WHERE endpoint = $1', [endpoint]);
    res.status(204).end();
  })
);

// ---------- proxy ("procuration") voters ----------

// Public, deliberately unauthenticated: this is how the voter page resolves
// a personal ?token=... link to a name + weight to show the voter. It's
// safe precisely because it requires already knowing the exact, unguessable
// token — there is no way to list or enumerate voters through this route,
// only to look up the one you already hold (unlike GET /api/voters below,
// which lists everyone and stays admin-only).
app.get(
  '/api/voters/:token',
  wrap(async (req, res) => {
    const { rows } = await pool.query('SELECT * FROM voters WHERE token = $1', [req.params.token]);
    if (!rows[0]) return res.status(404).json({ error: 'Lien de vote invalide.' });
    const ballots = ballotsFor(rows[0]);
    res.json({ displayName: rows[0].display_name, weight: ballots.length, ballots });
  })
);

app.get(
  '/api/voters',
  requireAdmin,
  wrap(async (req, res) => {
    const { rows } = await pool.query('SELECT * FROM voters ORDER BY created_at ASC');
    res.json(
      rows.map((v) => {
        const ballots = ballotsFor(v);
        return {
          token: v.token,
          displayName: v.display_name,
          weight: ballots.length,
          proxyNames: ballots.filter((b) => !b.own).map((b) => b.label),
        };
      })
    );
  })
);

app.post(
  '/api/voters',
  requireAdmin,
  wrap(async (req, res) => {
    const { displayName, proxyNames } = req.body || {};
    if (!displayName || typeof displayName !== 'string' || !displayName.trim()) {
      return res.status(400).json({ error: 'Le nom est requis.' });
    }
    const names = (Array.isArray(proxyNames) ? proxyNames : [])
      .map((n) => (typeof n === 'string' ? n.trim() : ''))
      .filter(Boolean);
    if (names.length === 0) {
      return res.status(400).json({ error: 'Ajoute au moins une personne représentée (procuration).' });
    }
    if (names.length > 20) {
      return res.status(400).json({ error: 'Maximum 20 procurations par personne.' });
    }

    const token = uuidv4();
    const weight = 1 + names.length;
    await pool.query('INSERT INTO voters (token, display_name, weight, proxy_names) VALUES ($1, $2, $3, $4)', [
      token,
      displayName.trim(),
      weight,
      JSON.stringify(names),
    ]);
    res.status(201).json({ token, displayName: displayName.trim(), weight, proxyNames: names });
  })
);

app.delete(
  '/api/voters/:token',
  requireAdmin,
  wrap(async (req, res) => {
    // Deliberately does not touch already-cast votes tied to this token —
    // revoking access shouldn't retroactively change a result that was
    // already part of a closed (or live) tally.
    await pool.query('DELETE FROM voters WHERE token = $1', [req.params.token]);
    res.status(204).end();
  })
);

// ---------- export (raw data the admin's PDF button builds from) ----------

// Admin-gated (unlike /api/questions/:id/results, which is left open — see
// the comment on that route): this endpoint dumps EVERY question at once,
// so it's the one place a stray URL guess would most easily hand someone
// the whole AG's results in one shot. Gating it costs nothing and matches
// the "results stay hidden while open" requirement more strictly.
//
// A question that isn't closed yet never gets a tally computed at all here
// (not just hidden client-side) — its breakdown by choice must not leak
// through this endpoint while voting is still in progress.
app.get(
  '/api/export/results',
  requireAdmin,
  wrap(async (req, res) => {
    res.json(await buildResultsSnapshot());
  })
);

// ---------- projector screen (read-only, no PIN) ----------
//
// What the room sees: the open question with its live vote count (never the
// breakdown), or else the last closed question with its final result —
// the same information that is shown publicly anyway once a vote closes.
app.get(
  '/api/screen',
  wrap(async (req, res) => {
    const { rows: openRows } = await pool.query("SELECT * FROM questions WHERE status = 'open' LIMIT 1");
    if (openRows[0]) {
      const voteCount = await voteRowCountFor(openRows[0].id);
      return res.json({ mode: 'open', question: questionRow(openRows[0]), voteCount });
    }
    const { rows: closedRows } = await pool.query(
      "SELECT * FROM questions WHERE status = 'closed' ORDER BY closed_at DESC NULLS LAST LIMIT 1"
    );
    if (closedRows[0]) {
      const { tally, total } = await tallyFor(closedRows[0].id);
      return res.json({ mode: 'closed', question: questionRow(closedRows[0]), tally, total });
    }
    res.json({ mode: 'idle' });
  })
);

// ---------- archive + new AG ----------

async function buildResultsSnapshot() {
  const { rows: questions } = await pool.query('SELECT * FROM questions ORDER BY order_index ASC');
  const results = [];
  for (const q of questions) {
    if (q.status === 'closed') {
      const { tally, total } = await tallyFor(q.id);
      results.push({ ...questionRow(q), tally, total });
    } else {
      results.push({ ...questionRow(q), tally: null, total: null });
    }
  }
  return results;
}

// "Nouvelle AG": saves the finished session as an archive (questions + final
// results), then clears questions, votes and — optionally — the proxy links,
// so the next AG starts from an empty board. Refused while a question is open.
app.post(
  '/api/session/new',
  requireAdmin,
  wrap(async (req, res) => {
    const { title, deleteVoters } = req.body || {};
    const { rows: openRows } = await pool.query("SELECT id FROM questions WHERE status = 'open'");
    if (openRows.length) {
      return res.status(400).json({ error: "Ferme la question ouverte avant de démarrer une nouvelle AG." });
    }
    const snapshot = await buildResultsSnapshot();
    const archiveTitle =
      (typeof title === 'string' && title.trim()) || `AG du ${new Date().toLocaleDateString('fr-CH')}`;

    const client = await pool.connect();
    let archiveId = null;
    try {
      await client.query('BEGIN');
      if (snapshot.length) {
        archiveId = uuidv4();
        await client.query('INSERT INTO archives (id, title, data) VALUES ($1, $2, $3)', [
          archiveId,
          archiveTitle,
          JSON.stringify({ questions: snapshot }),
        ]);
      }
      await client.query('DELETE FROM votes');
      await client.query('DELETE FROM questions');
      if (deleteVoters) await client.query('DELETE FROM voters');
      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
    for (const id of timers.keys()) clearTimer(id);
    io.emit('questions:changed');
    io.emit('session:reset');
    res.json({ ok: true, archiveId, archivedQuestions: snapshot.length });
  })
);

app.get(
  '/api/archives',
  requireAdmin,
  wrap(async (req, res) => {
    const { rows } = await pool.query(
      "SELECT id, title, created_at, jsonb_array_length(data->'questions') AS question_count FROM archives ORDER BY created_at DESC"
    );
    res.json(rows.map((r) => ({ id: r.id, title: r.title, createdAt: r.created_at, questionCount: r.question_count })));
  })
);

app.get(
  '/api/archives/:id',
  requireAdmin,
  wrap(async (req, res) => {
    const { rows } = await pool.query('SELECT * FROM archives WHERE id = $1', [req.params.id]);
    if (!rows[0]) return res.status(404).json({ error: 'Archive introuvable.' });
    res.json({ id: rows[0].id, title: rows[0].title, createdAt: rows[0].created_at, questions: rows[0].data.questions });
  })
);

app.get('/api/health', (req, res) => res.json({ ok: true }));

// Error middleware — must be registered last, after every route.
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Erreur interne du serveur.' });
});

io.on('connection', () => {
  // nothing to do on connect yet — clients just listen for broadcasts.
});

async function main() {
  try {
    await init();
  } catch (err) {
    console.error('Could not connect to Postgres / initialize schema:', err.message);
    console.error('Check DATABASE_URL in .env and that Postgres is running (see docker-compose.yml for local dev).');
    process.exit(1);
  }

  // A countdown with auto-close that was running when the server restarted
  // (e.g. a redeploy) is re-armed, or closed right away if it already ran out.
  const { rows: running } = await pool.query(
    "SELECT * FROM questions WHERE status = 'open' AND timer_ends_at IS NOT NULL AND timer_auto_close"
  );
  for (const q of running) {
    scheduleAutoClose(q.id, new Date(q.timer_ends_at).getTime() - Date.now());
  }

  server.listen(PORT, () => {
    console.log(`AG voting tool listening on http://localhost:${PORT}`);
    if (ADMIN_PIN === 'changeme') {
      console.warn('WARNING: ADMIN_PIN is still the default. Set a real one in .env before using this for real.');
    }
  });
}

main();
